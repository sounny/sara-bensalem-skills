import json
import os

ROOT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

rubric = {
  "title": "Sara Bensalem 100-Point Spatial Portfolio Audit Rubric (2026 Enhanced Edition)",
  "author": "Sara Bensalem <sara@sarabensalem.com>",
  "website": "https://skills.sarabensalem.com",
  "total_points": 100,
  "categories": [
    {
      "id": "narrative_curation",
      "name": "Narrative Arc & Strategic Curation",
      "max_points": 20,
      "criteria": [
        {
          "id": "passport_clarity",
          "points": 5,
          "desc": "Project Passport clarity: explicitly stating typology, gross area, location, software stack, and line-item individual attribution (preventing the 'Mystery Role' red flag)."
        },
        {
          "id": "5_act_narrative_pacing",
          "points": 5,
          "desc": "5-Act spatial case study structure (Hook -> Context/Constraints -> Spatial Anatomy -> Tectonic Proof -> Lived Climax) or sequential graphic novel framing."
        },
        {
          "id": "scannable_hierarchy",
          "points": 5,
          "desc": "Scannable typography hierarchy (Space Grotesk display, Inter body, JetBrains Mono metadata) structured for 15s/30s recruiter triage."
        },
        {
          "id": "problem_resolution",
          "points": 5,
          "desc": "Clear articulation of real constraints (soil salinity, urban density, tight budgets, seismic/flood risk) and verifiable architectural resolution."
        }
      ]
    },
    {
      "id": "constructive_rigor",
      "name": "Constructive Rigor & Technical Proof (Anti-Render-Trap)",
      "max_points": 25,
      "criteria": [
        {
          "id": "scaled_plans",
          "points": 8,
          "desc": "Scaled architectural orthographics (1:100 to 1:20) with hierarchy of lineweights (cut profiles 0.50mm, secondary assemblies 0.25mm, hairlines 0.13mm)."
        },
        {
          "id": "layered_wall_sections",
          "points": 7,
          "desc": "Layered 1:20 constructive wall sections specifying waterproofing membranes, insulation lambda values, U-value calculation, and continuous structural thermal breaks."
        },
        {
          "id": "dimension_chains",
          "points": 5,
          "desc": "Legible closed dimension strings, structural column grids, level datum lines (FFL/TOS), and graphic scale bars."
        },
        {
          "id": "code_accessibility",
          "points": 5,
          "desc": "Demonstrated universal accessibility (1500mm PMR/ADA wheelchair turning circles, 900mm door arcs) and IBC emergency egress compliance."
        }
      ]
    },
    {
      "id": "swiss_grid_layout",
      "name": "Layout, Swiss Grid & Typographic Discipline",
      "max_points": 20,
      "criteria": [
        {
          "id": "grid_consistency",
          "points": 5,
          "desc": "Rigorous multi-column grid discipline (8, 12, or 16 columns) with synchronized horizontal baseline rhythm across all spreads."
        },
        {
          "id": "type_hierarchy",
          "points": 5,
          "desc": "Restrained typographic palette (maximum 2 typeface families, 3 standardized scale tiers), avoiding font chaos."
        },
        {
          "id": "white_space_breathing",
          "points": 5,
          "desc": "Generous negative space (35-50% breathing room, such as the 50% left text margin rule) preventing visual claustrophobia."
        },
        {
          "id": "visual_rhythm",
          "points": 5,
          "desc": "Dynamic visual rhythm alternating between macro contextual overviews and high-density technical plate sets."
        }
      ]
    },
    {
      "id": "multi_scale_fluency",
      "name": "Multi-Scale Spatial Fluency (Trust Trifecta)",
      "max_points": 15,
      "criteria": [
        {
          "id": "macro_urban_context",
          "points": 5,
          "desc": "Macro scale (1:500 - 1:1000): Topographical contours, hydrological bioswales, transit connectivity, or urban morphology block typologies."
        },
        {
          "id": "meso_building_scale",
          "points": 5,
          "desc": "Meso scale (1:100 - 1:50): Comprehensive floor plans, circulation spines, spatial sequencing, and programmatic zoning."
        },
        {
          "id": "micro_joinery_detail",
          "points": 5,
          "desc": "Micro scale (1:20 - 1:5): Demountable pin joints, custom cabinetry reveals (joint creux), concealed hardware pockets, or 1:1 material prototypes."
        }
      ]
    },
    {
      "id": "materiality_scenography",
      "name": "Materiality, Climate & Environmental Simulation",
      "max_points": 10,
      "criteria": [
        {
          "id": "environmental_simulation",
          "points": 4,
          "desc": "Environmental performance proof: Solar altitude vectors, natural ventilation stack loops, or Ladybug/Honeybee radiation heatmaps and thermal comfort metrics."
        },
        {
          "id": "diurnal_lighting",
          "points": 3,
          "desc": "Diurnal study: Paired day/night elevations or daylight factor simulation demonstrating both daylight control and nocturnal social activation."
        },
        {
          "id": "material_harmony",
          "points": 3,
          "desc": "Material-grounded color harmony derived from authentic construction geology (terracotta, stone, timber, steel) rather than saturated digital gradients."
        }
      ]
    },
    {
      "id": "professional_delivery",
      "name": "Professional Delivery & Conversion Integrity",
      "max_points": 10,
      "criteria": [
        {
          "id": "file_optimization",
          "points": 4,
          "desc": "Optimized PDF binary (< 50 MB) ensuring rapid loading across email and web screening passes."
        },
        {
          "id": "real_world_proof",
          "points": 3,
          "desc": "Documented construction validation (on-site supervision logs, built freelance commissions, competition awards, or tier-1 consultant internships)."
        },
        {
          "id": "clean_colophon_cta",
          "points": 3,
          "desc": "Direct running contact footer (email, phone, mobility rights), software competency badges, and clear career intent."
        }
      ]
    }
  ]
}

target_path = os.path.join(ROOT_DIR, 'skills', 'portfolio-monograph', 'resources', 'rubric_100pt.json')
with open(target_path, 'w', encoding='utf-8') as f:
    json.dump(rubric, f, indent=2)
print(f'Wrote {target_path}')

